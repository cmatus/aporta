$(document).ready(function(){
	$("#divMenu").click(function(){
		if($("nav.desplegable").css("left") == "0px") {
			$("nav.desplegable").css("left", "-200px")
		} else {
			$("nav.desplegable").css("left", "0px");
		}
	});
})